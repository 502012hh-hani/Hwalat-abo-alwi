package com.abualawi.hawalat;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.*;
import android.view.View;
import java.util.*;

public class MainActivity extends Activity {
    TextView status, entries;
    Button enable, export;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(28, 36, 28, 28);
        layout.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView title = new TextView(this);
        title.setText("حوالات أبو علوي");
        title.setTextSize(28);
        title.setGravity(17);
        layout.addView(title);
        status = new TextView(this);
        status.setText("مصدر الرسائل: ابو علوي رقم جديد\nالمجموعتان: العمقي وبن دول");
        status.setTextSize(18);
        layout.addView(status);
        enable = new Button(this);
        enable.setText("تفعيل الوصول إلى إشعارات واتساب");
        layout.addView(enable);
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        entries = new TextView(this);
        entries.setTextSize(16);
        entries.setPadding(0,24,0,24);
        entries.setText("لم تُسجّل حوالات بعد. فعّل الإشعارات ثم اختبر وصول رسالة جديدة.");
        layout.addView(entries);
        export = new Button(this);
        export.setText("تصدير ملفات الحوالات اليومية");
        layout.addView(export);
        export.setOnClickListener(v -> Toast.makeText(this, "سيُضاف تصدير Excel بعد اختبار شكل إشعارات واتساب على هاتفك.", Toast.LENGTH_LONG).show());
        setContentView(layout);
    }
}

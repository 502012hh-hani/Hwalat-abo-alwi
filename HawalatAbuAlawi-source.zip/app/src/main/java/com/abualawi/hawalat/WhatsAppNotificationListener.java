package com.abualawi.hawalat;

import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.app.Notification;
import android.os.Bundle;
import android.content.SharedPreferences;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WhatsAppNotificationListener extends NotificationListenerService {
    @Override public void onNotificationPosted(StatusBarNotification sbn) {
        if (!"com.whatsapp".equals(sbn.getPackageName())) return;
        Notification n = sbn.getNotification();
        Bundle x = n.extras;
        if (x == null) return;
        String title = String.valueOf(x.getCharSequence(Notification.EXTRA_TITLE, ""));
        String body = String.valueOf(x.getCharSequence(Notification.EXTRA_TEXT, ""));
        String big = String.valueOf(x.getCharSequence(Notification.EXTRA_BIG_TEXT, ""));
        String text = (body + " " + big).trim();
        if (text.isEmpty()) return;
        // WhatsApp notifications may omit group/sender details depending on privacy settings.
        String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date(sbn.getPostTime()));
        SharedPreferences p = getSharedPreferences("hawalat", MODE_PRIVATE);
        String old = p.getString("raw", "");
        String row = stamp + " | " + title + " | " + text;
        p.edit().putString("raw", old + row + "\n").apply();
    }
}
